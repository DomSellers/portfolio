import Foundation

class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = []

    private let tasksKey = "tasks"

    init() {
        loadTasks()
    }

    func addTask(task: Task) {
        tasks.append(task)
        saveTasks()
    }

    func deleteTask(indexSet: IndexSet) {
        tasks.remove(atOffsets: indexSet)
        saveTasks()
    }

    func toggleTaskCompletion(task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted.toggle()
            saveTasks()
        }
    }

    func saveTasks() {
        if let encodedTasks = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encodedTasks, forKey: tasksKey)
        }
    }

    func loadTasks() {
        if let savedTasks = UserDefaults.standard.data(forKey: tasksKey),
           let decodedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
            tasks = decodedTasks
        }
    }
}
