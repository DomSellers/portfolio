import SwiftUI

struct TaskListView: View {
    @StateObject private var viewModel = TaskViewModel()
    @State private var showingAddTaskView = false
    @State private var selectedSortOption: SortOption = .alphabetical // Default sort option

    var body: some View {
        NavigationView {
            VStack {
                Picker("Sort By", selection: $selectedSortOption) {
                    ForEach(SortOption.allCases, id: \.self) { option in
                        Text(option.displayName).tag(option)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                List {
                    ForEach(sortedTasks) { task in
                        HStack {
                            // Checkbox for marking task as completed
                            Button(action: {
                                viewModel.toggleTaskCompletion(task: task)
                            }) {
                                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(task.isCompleted ? .green : .gray)
                            }

                            // Task details with conditional styling for completed tasks
                            VStack(alignment: .leading) {
                                Text(task.name)
                                    .font(.headline)
                                    .strikethrough(task.isCompleted, color: .gray)
                                    .foregroundColor(task.isCompleted ? .gray : .primary)
                                if let dueDate = task.dueDate {
                                    Text("Due: \(formatDate(dueDate))")
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                            }
                            Spacer()
                            Text(task.priority)
                                .foregroundColor(.blue)
                        }
                    }
                    .onDelete(perform: viewModel.deleteTask)
                }
            }
            .navigationTitle("To-Do List")
            .navigationBarItems(
                trailing: Button(action: {
                    showingAddTaskView.toggle()
                }) {
                    Image(systemName: "plus")
                }
            )
            .sheet(isPresented: $showingAddTaskView) {
                AddTaskView(viewModel: viewModel)
            }
        }
    }

    // Computed property to sort tasks based on the selected sort option
    private var sortedTasks: [Task] {
        switch selectedSortOption {
        case .alphabetical:
            return viewModel.tasks.sorted { $0.name.lowercased() < $1.name.lowercased() }
        case .priority:
            return viewModel.tasks.sorted { $0.priority < $1.priority }
        case .date:
            return viewModel.tasks.sorted { ($0.dueDate ?? Date.distantFuture) < ($1.dueDate ?? Date.distantFuture) }
        }
    }

    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}

// Enum to define sorting options
enum SortOption: String, CaseIterable {
    case alphabetical
    case priority
    case date

    var displayName: String {
        switch self {
        case .alphabetical: return "Alphabetical"
        case .priority: return "Priority"
        case .date: return "Date"
        }
    }
}
