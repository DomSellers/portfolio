//
//  _DoTests.swift
//  2DoTests
//
//  Created by Dominic Sellers on 02/01/2025.
//

import Testing
@testable import _Do

struct _DoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
