//
//  TaskView.swift
//  2Do
//
//  Created by Dominic Sellers on 02/01/2025.
//

import SwiftUI

struct Task: Identifiable, Codable {
    var id = UUID()
    var name: String
    var priority: String
    var dueDate: Date?
    var category: String?
    var isCompleted: Bool = false
    var recurrence: String = "None"
}

struct AddTaskView: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var viewModel: TaskViewModel

    @State private var name = ""
    @State private var priority = "Medium"
    @State private var dueDate = Date()
    @State private var category = "Personal"
    @State private var recurrence = "None"

    var body: some View {
        NavigationView {
            Form {
                TextField("Task Name", text: $name)
                Picker("Priority", selection: $priority) {
                    Text("High").tag("High")
                    Text("Medium").tag("Medium")
                    Text("Low").tag("Low")
                }
                DatePicker("Due Date", selection: $dueDate, displayedComponents: .date)
                TextField("Category", text: $category)
                Picker("Recurrence", selection: $recurrence) {
                    Text("None").tag("None")
                    Text("Daily").tag("Daily")
                    Text("Weekly").tag("Weekly")
                    Text("Monthly").tag("Monthly")
                }
            }
            .navigationBarTitle("Add Task", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Save") {
                    let newTask = Task(
                        name: name,
                        priority: priority,
                        dueDate: dueDate,
                        category: category,
                        isCompleted: false,
                        recurrence: recurrence
                    )
                    viewModel.addTask(task: newTask)
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
}
