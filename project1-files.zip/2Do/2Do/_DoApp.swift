//
//  _DoApp.swift
//  2Do
//
//  Created by Dominic Sellers on 02/01/2025.
//

import Foundation
import SwiftUI

@main
struct _DoApp: App {
    var body: some Scene {
        WindowGroup {
            TabView {
                TaskListView()
                    .tabItem {
                        Image(systemName: "list.bullet")
                        Text("Tasks")
                    }

                TimerView()
                    .tabItem {
                        Image(systemName: "timer")
                        Text("Timer")
                    }
            }
        }
    }
}



