//
//  TimerView.swift
//  2Do
//
//  Created by Dominic Sellers on 02/01/2025.
//

import SwiftUI

struct TimerView: View {
    @State private var timeRemaining = 25 * 60 // Default Pomodoro duration (25 minutes)
    @State private var isRunning = false
    @State private var timer: Timer?

    var body: some View {
        VStack(spacing: 20) {
            Text(formatTime())
                .font(.system(size: 60, weight: .bold, design: .monospaced))
                .padding()

            HStack {
                Button(action: startTimer) {
                    Text(isRunning ? "Pause" : "Start")
                        .font(.title2)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(isRunning ? Color.red : Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

                Button(action: resetTimer) {
                    Text("Reset")
                        .font(.title2)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()

            Text("Stay focused and complete your tasks!")
                .font(.headline)
                .foregroundColor(.secondary)
        }
        .padding()
        .onDisappear {
            timer?.invalidate()
        }
    }

    private func formatTime() -> String {
        let minutes = timeRemaining / 60
        let seconds = timeRemaining % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }

    private func startTimer() {
        if isRunning {
            timer?.invalidate()
            isRunning = false
        } else {
            isRunning = true
            timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
                if timeRemaining > 0 {
                    timeRemaining -= 1
                } else {
                    timer?.invalidate()
                    isRunning = false
                    // Optional: Trigger notification or alert
                }
            }
        }
    }

    private func resetTimer() {
        timer?.invalidate()
        isRunning = false
        timeRemaining = 25 * 60
    }
}
